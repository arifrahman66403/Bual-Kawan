<?php if (isset($component)) { $__componentOriginal2e6fb18f75884c4fed4e10444e669251 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2e6fb18f75884c4fed4e10444e669251 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-admin','data' => ['title' => 'Riwayat Tracking']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Riwayat Tracking']); ?>
    <h2 class="mb-4 fw-bold text-color">Riwayat Perubahan Status Kunjungan 🔄</h2>
    <div class="card p-4">
      <!-- Header tabel -->
      <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
          <h5 class="fw-bold text-color mb-2 mb-md-0">Data Perubahan Terbaru</h5>
          
          <div class="d-flex gap-2">
              
              <form action="<?php echo e(route('admin.riwayat')); ?>" method="GET" class="d-flex gap-2 flex-wrap">
                  
                  
                  <select name="tipe" class="form-select form-select-sm" style="width: 160px;" onchange="this.form.submit()">
                      <option value="">Semua Tipe</option>
                      <option value="instansi pemerintah" <?php echo e(request('tipe') == 'instansi pemerintah' ? 'selected' : ''); ?>>Instansi Pemerintah</option>
                      <option value="masyarakat umum" <?php echo e(request('tipe') == 'masyarakat umum' ? 'selected' : ''); ?>>Masyarakat Umum</option>
                  </select>    
  
                  
                  <select name="bulan" class="form-select form-select-sm" style="width: 130px;" onchange="this.form.submit()">
                      <option value="">Semua Bulan</option>
                      <?php $__currentLoopData = range(1,12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($month); ?>" <?php echo e(request('bulan') == $month ? 'selected' : ''); ?>>
                              <?php echo e(\Carbon\Carbon::create()->month($month)->locale('id')->monthName); ?>

                          </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
  
                  
                  <select name="tahun" class="form-select form-select-sm" style="width: 100px;" onchange="this.form.submit()">
                      <option value="">Semua Tahun</option>
                      <?php for($year = date('Y'); $year >= date('Y') - 2; $year--): ?>
                          <option value="<?php echo e($year); ?>" <?php echo e(request('tahun') == $year ? 'selected' : ''); ?>>
                              <?php echo e($year); ?>

                          </option>
                      <?php endfor; ?>
                  </select>
              </form>

              
              <button type="button" class="btn btn-sm btn-outline-success" data-bs-toggle="modal" data-bs-target="#exportModal">
                  <i class="bi bi-file-earmark-excel"></i> Export
              </button>

              
                <a href="<?php echo e(route('admin.riwayat')); ?>" class="btn btn-sm btn-secondary">
                    <i class="bi bi-arrow-clockwise"></i>
                </a>
          </div>
      </div>
  
      <!-- Tabel -->
      <div class="table-responsive">
        <table class="table table-hover align-middle table-borderless" id="dataRiwayat">
          <thead class="table-primary">
            <tr>
              <th>#</th>
              <th>Nama Instansi</th>
              <th>Status</th>
              <th>Catatan</th>
              <th>Diperbarui Oleh</th>
              <th>Tanggal</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $trackings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($trackings->firstItem() + $no); ?></td>
              <td>
                <span class="fw-semibold text-color"><?php echo e($t->pengunjung->nama_instansi ?? '-'); ?></span>
                <?php if($t->pengunjung && $t->pengunjung->tipe_pengunjung): ?>
                    <br><small class="text-muted" style="font-size: 0.7rem;">(<?php echo e(ucfirst($t->pengunjung->tipe_pengunjung)); ?>)</small>
                <?php endif; ?>
              </td>
              <td>
                <span class="badge 
                  <?php if($t->status=='pengajuan'): ?> bg-secondary 
                  <?php elseif($t->status=='disetujui'): ?> bg-success 
                  <?php elseif($t->status=='kunjungan'): ?> bg-info 
                  <?php elseif($t->status=='selesai'): ?> bg-primary 
                  <?php else: ?> bg-dark <?php endif; ?>">
                  <?php echo e(ucfirst($t->status)); ?>

                </span>
              </td>
              <td><?php echo e($t->catatan ?? '-'); ?></td>
              <td><?php echo e($t->createdBy->nama ?? 'System'); ?></td>
              <td><?php echo e(\Carbon\Carbon::parse($t->created_at)->format('d M Y H:i')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="6" class="text-center text-muted py-4">Belum ada riwayat perubahan status.</td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
  
      <!-- Pagination -->
      <div class="mt-3 d-flex justify-content-center">
        <?php echo e($trackings->withQueryString()->links()); ?>

      </div>
  
    </div> 
    
  
    
    
    
    <div class="modal fade" id="exportModal" tabindex="-1" aria-labelledby="exportModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-sm modal-dialog-centered">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title fw-bold" id="exportModalLabel">Filter Export Excel</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              
              <form action="<?php echo e(route('admin.riwayat.export')); ?>" method="GET">
                  <div class="modal-body">
                      
                      
                      <div class="mb-3">
                          <label for="export_tipe" class="form-label small fw-semibold">Tipe Pengunjung</label>
                          <select class="form-select form-select-sm" name="tipe" id="export_tipe">
                              <option value="">Semua Tipe</option>
                              <option value="instansi pemerintah" <?php echo e(request('tipe') == 'instansi pemerintah' ? 'selected' : ''); ?>>Instansi Pemerintah</option>
                              <option value="masyarakat umum" <?php echo e(request('tipe') == 'masyarakat umum' ? 'selected' : ''); ?>>Masyarakat Umum</option>
                          </select>
                      </div>

                      <div class="mb-3">
                          <label for="export_bulan" class="form-label small fw-semibold">Pilih Bulan</label>
                          <select class="form-select form-select-sm" name="bulan" id="export_bulan">
                              <option value="" selected>Semua Bulan</option>
                              <?php $__currentLoopData = range(1, 12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($month); ?>" <?php echo e(request('bulan') == $month ? 'selected' : ''); ?>>
                                      <?php echo e(\Carbon\Carbon::create()->month($month)->locale('id')->monthName); ?>

                                  </option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>

                      <div class="mb-3">
                          <label for="export_tahun" class="form-label small fw-semibold">Pilih Tahun</label>
                          <select class="form-select form-select-sm" name="tahun" id="export_tahun">
                              <option value="">Semua Tahun</option>
                              <?php for($year = date('Y'); $year >= date('Y') - 2; $year--): ?>
                                  <option value="<?php echo e($year); ?>" <?php echo e(request('tahun') == $year ? 'selected' : ''); ?>><?php echo e($year); ?></option>
                              <?php endfor; ?>
                          </select>
                      </div>

                  </div>
                  <div class="modal-footer border-0 pt-0">
                      <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Batal</button>
                      <button type="submit" class="btn btn-sm btn-success w-100">
                          <i class="bi bi-download me-1"></i> Download Excel
                      </button>
                  </div>
              </form>
          </div>
      </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2e6fb18f75884c4fed4e10444e669251)): ?>
<?php $attributes = $__attributesOriginal2e6fb18f75884c4fed4e10444e669251; ?>
<?php unset($__attributesOriginal2e6fb18f75884c4fed4e10444e669251); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e6fb18f75884c4fed4e10444e669251)): ?>
<?php $component = $__componentOriginal2e6fb18f75884c4fed4e10444e669251; ?>
<?php unset($__componentOriginal2e6fb18f75884c4fed4e10444e669251); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\bual_kawan\resources\views/admin/riwayat.blade.php ENDPATH**/ ?>