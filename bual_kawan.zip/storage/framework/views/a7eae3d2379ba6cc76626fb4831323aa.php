<?php if (isset($component)) { $__componentOriginal2e6fb18f75884c4fed4e10444e669251 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2e6fb18f75884c4fed4e10444e669251 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-admin','data' => ['title' => 'Manajemen Admin']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Manajemen Admin']); ?>

  <h2 class="mb-4 fw-bold text-color">Manajemen Administrator 👥</h2>

  <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show mb-3" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <div class="card p-4">

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
      <h5 class="fw-bold text-color mb-2 mb-md-0">Daftar Pengguna Sistem</h5>
      <div class="d-flex gap-2">
        <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-sm btn-primary">
            <i class="bi bi-person-plus-fill"></i> Tambah User
        </a>
        
        <form method="GET" action="<?php echo e(route('admin.users.index')); ?>" class="d-flex">
             <input type="text" name="search" class="form-control form-control-sm me-2" placeholder="Cari nama/user..." value="<?php echo e(request('search')); ?>">
             <button class="btn btn-sm btn-outline-secondary" type="submit"><i class="bi bi-search"></i></button>
        </form>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table table-hover align-middle table-borderless">
        <thead class="table-primary">
          <tr>
            <th>No</th>
            <th>Nama & Kontak</th>
            <th>Username / Role</th>
            <th>Status</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($users->firstItem() + $no); ?></td>
            <td>
              <span class="fw-bold text-color"><?php echo e($user->nama); ?></span><br>
              <small class="text-muted"><?php echo e($user->email); ?></small>
              <?php if($user->wa): ?> 
                <br><small class="text-success"><i class="bi bi-whatsapp"></i> <?php echo e($user->wa); ?></small> 
              <?php endif; ?>
            </td>
            <td>
                <div class="d-flex flex-column">
                    <span class="fw-semibold">@ <?php echo e($user->user); ?></span>
                    <span class="badge bg-secondary align-self-start mt-1"><?php echo e(strtoupper($user->role)); ?></span>
                </div>
            </td>
            <td>
                <?php if($user->is_active == 1): ?>
                    <span class="badge bg-success"><i class="bi bi-check-circle"></i> Aktif</span>
                <?php else: ?>
                    <span class="badge bg-danger"><i class="bi bi-x-circle"></i> Non-Aktif</span>
                <?php endif; ?>
            </td>
            <td class="text-end">
                <div class="d-flex justify-content-end gap-1">
                    
                    <form action="<?php echo e(route('admin.users.toggle', $user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit" class="btn btn-sm <?php echo e($user->is_active ? 'btn-outline-warning' : 'btn-outline-success'); ?>" 
                                title="<?php echo e($user->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?>">
                            <i class="bi <?php echo e($user->is_active ? 'bi-slash-circle' : 'bi-check-lg'); ?>"></i>
                        </button>
                    </form>

                    <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-sm btn-info text-white" title="Edit">
                        <i class="bi bi-pencil-square"></i>
                    </a>

                    <form onsubmit="return confirm('Yakin ingin menghapus user ini?');" 
                          action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" 
                          method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger" title="Hapus">
                            <i class="bi bi-trash"></i>
                        </button>
                    </form>
                </div>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="5" class="text-center text-muted py-4">Tidak ada data administrator.</td>
          </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <div class="mt-3 d-flex justify-content-end">
      <?php echo e($users->links()); ?>

    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2e6fb18f75884c4fed4e10444e669251)): ?>
<?php $attributes = $__attributesOriginal2e6fb18f75884c4fed4e10444e669251; ?>
<?php unset($__attributesOriginal2e6fb18f75884c4fed4e10444e669251); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e6fb18f75884c4fed4e10444e669251)): ?>
<?php $component = $__componentOriginal2e6fb18f75884c4fed4e10444e669251; ?>
<?php unset($__componentOriginal2e6fb18f75884c4fed4e10444e669251); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\bual_kawan\resources\views/admin/users/index.blade.php ENDPATH**/ ?>