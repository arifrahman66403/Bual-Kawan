<?php if (isset($component)) { $__componentOriginal2e6fb18f75884c4fed4e10444e669251 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2e6fb18f75884c4fed4e10444e669251 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-admin','data' => ['title' => 'Dashboard Operator']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard Operator']); ?>
    <div class="container-fluid pt-4">
        <h1 class="h3 mb-4 text-gray-800">Scan 📲 Kunjungan</h1>
        
        <?php if(session('success')): ?>
            <div class="alert alert-success"><i class="bi bi-check-circle-fill"></i> <?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill"></i> <?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <div class="card shadow-lg mb-5 scan-card">
            <div class="card-body text-center p-5">
                <div class="qr-icon position-relative d-inline-block mb-3">
                    <i class="bi bi-qr-code-scan display-1 text-primary mb-4"></i>
                    <div class="scan-line"></div>
                </div>

                <h4 class="card-title mb-4">Arahkan Scanner ke Kode QR Pengunjung</h4>
                
                <form id="scanForm" action="<?php echo e(route('operator.scan')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="input-group input-group-lg mx-auto" style="max-width: 500px;">
                        <input type="text" name="qr_code" class="form-control input-focus" placeholder="Masukkan Kode QR..." autofocus required>
                        <button id="submitBtn" class="btn btn-primary" type="submit">
                            <i class="bi bi-send-fill me-1"></i> Proses Check-in/out
                        </button>
                    </div>
                    <?php $__errorArgs = ['qr_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </form>

            </div>
        </div>
        
        <a href="<?php echo e(route('operator.riwayat')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-list-task me-2"></i> Lihat Riwayat Scan Hari Ini
        </a>
    </div>

    <!-- Loading overlay -->
    <div id="loadingOverlay" class="loading-overlay" aria-hidden="true">
        <div class="loading-box">
            <div class="spin" role="status" aria-hidden="true"></div>
            <div>
                <strong>Memproses scan...</strong>
                <div class="text-muted small">Tunggu sebentar</div>
            </div>
        </div>
    </div>

    <style>
        /* Card hover lift */
        .scan-card { transition: transform .25s ease, box-shadow .25s ease; }
        .scan-card:hover { transform: translateY(-8px); box-shadow: 0 12px 30px rgba(0,0,0,.18); }

        /* QR scan line */
        .qr-icon { width: 1fr; }
        .scan-line {
            position: absolute;
            left: 8%;
            right: 8%;
            height: 6px;
            background: linear-gradient(90deg, rgba(13,110,253,0) 0%, rgba(13,110,253,0.9) 50%, rgba(13,110,253,0) 100%);
            top: -10%;
            border-radius: 3px;
            animation: scan 1.6s linear infinite;
            animation-play-state: paused;
            pointer-events: none;
        }
        @keyframes scan {
            0% { top: -20%; opacity: 0; }
            10% { opacity: 1; }
            50% { top: 50%; opacity: 1; }
            90% { opacity: 1; }
            100% { top: 120%; opacity: 0; }
        }

        /* Input focus glow */
        .input-focus { transition: box-shadow .18s ease; }
        .input-focus:focus { box-shadow: 0 0 0 .25rem rgba(13,110,253,.15); outline: none; }

        /* Loading overlay */
        .loading-overlay{
            position: fixed; inset: 0;
            background: rgba(255,255,255,.75);
            display: none;
            align-items: center; justify-content: center;
            z-index: 1050;
        }
        .loading-box{
            background:#fff;padding:16px;border-radius:8px;
            box-shadow:0 8px 30px rgba(0,0,0,.12);
            display:flex;gap:12px;align-items:center;
        }
        .spin{width:36px;height:36px;border:4px solid #e9ecef;border-top-color:#0d6efd;border-radius:50%;animation:spin 1s linear infinite;}
        @keyframes spin{to{transform:rotate(360deg)}}
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function(){
            const form = document.getElementById('scanForm');
            const overlay = document.getElementById('loadingOverlay');
            // FIX: pilih input dengan nama yang benar
            const input = form ? form.querySelector('input[name="qr_code"]') : null;
            const btn = document.getElementById('submitBtn');
            const scanLine = document.querySelector('.scan-line');

            // safety: jika elemen tidak ada, hentikan script supaya tidak menyebabkan error
            if (!form || !input || !btn) return;

            // Toggle scanning animation while input focused
            input.addEventListener('focus', function(){ if (scanLine) scanLine.style.animationPlayState = 'running'; });
            input.addEventListener('blur', function(){ if (scanLine) scanLine.style.animationPlayState = 'paused'; });

            // On submit show overlay and disable button to give effect
            form.addEventListener('submit', function(e){
                btn.disabled = true;
                btn.dataset.origHtml = btn.innerHTML;
                btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span> Memproses...';
                overlay.style.display = 'flex';
            });

            // ensure autofocus focuses input in some browsers
            setTimeout(()=> { try { input.focus(); } catch(e){} }, 50);

            // Start scan-line for initial autofocus when page loads
            if (document.activeElement === input && scanLine) {
                scanLine.style.animationPlayState = 'running';
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2e6fb18f75884c4fed4e10444e669251)): ?>
<?php $attributes = $__attributesOriginal2e6fb18f75884c4fed4e10444e669251; ?>
<?php unset($__attributesOriginal2e6fb18f75884c4fed4e10444e669251); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e6fb18f75884c4fed4e10444e669251)): ?>
<?php $component = $__componentOriginal2e6fb18f75884c4fed4e10444e669251; ?>
<?php unset($__componentOriginal2e6fb18f75884c4fed4e10444e669251); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\bual_kawan\resources\views/operator/dashboard.blade.php ENDPATH**/ ?>