<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Konfirmasi Data Peserta']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Konfirmasi Data Peserta']); ?>
    
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card p-5 text-center shadow-lg border-success border-3">
                    <i class="bi bi-check-circle-fill text-success" style="font-size: 4rem;"></i>
                    
                    <h2 class="fw-bold text-success mt-3">Data Berhasil Dikirim!</h2>
                    
                    
                    <?php if(session('success')): ?>
                        <p class="lead mt-3"><?php echo e(session('success')); ?></p>
                    <?php endif; ?>

                    <hr>
                    
                    <p class="text-muted">
                        Terima kasih, **<?php echo e($pengunjung->nama_perwakilan); ?>**! Data seluruh peserta rombongan dari **<?php echo e($pengunjung->nama_instansi); ?>** untuk kunjungan pada tanggal 
                        **<?php echo e(Carbon\Carbon::parse($pengunjung->tgl_kunjungan)->format('d F Y')); ?>** telah berhasil direkam.
                    </p>

                    <a href="/" class="btn btn-outline-secondary mt-4">
                        <i class="bi bi-house"></i> Kembali ke Halaman Utama
                    </a>
                </div>
            </div>
        </div>
    </div>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\bual_kawan\resources\views/kunjungan/konfirmasi.blade.php ENDPATH**/ ?>