<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Form Tambah Kunjungan Baru']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Form Tambah Kunjungan Baru']); ?>
    <div class="container py-5">
        <div class="form-card shadow-lg mx-auto p-4" style="max-width: 1000px;">
            
            <h3 class="mb-4 fw-bold">Form Daftar Kunjungan</h3>
            
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            
            <form action="<?php echo e(route('kunjungan.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="row">
                    
                    
                    <div class="col-md-6 border-end pe-md-4">
                        <h5 class="mt-2 mb-4 input-group-label">Data Instansi</h5>

                        
                        <div class="mb-3">
                            <label class="form-label d-block">Tipe Pengunjung</label>
                                <input type="radio" name="tipe_pengunjung" value="instansi pemerintah" id="tipe_instansi" <?php echo e(old('tipe_pengunjung') == 'instansi pemerintah' ? 'checked' : ''); ?>>
                                <label for="tipe_instansi" class="me-3">Instansi Pemerintah</label>
                                <input type="radio" name="tipe_pengunjung" value="masyarakat umum" id="tipe_masyarakat" <?php echo e(old('tipe_pengunjung') == 'masyarakat umum' ? 'checked' : ''); ?>>
                                <label for="tipe_masyarakat">Masyarakat Umum</label>
                        </div>
                        
                        
                        <div class="mb-3">
                            <label for="kode_daerah" class="form-label">Asal Daerah</label>
                            <input type="text" class="form-control" id="kode_daerah" name="kode_daerah" placeholder="Contoh: Riau" value="<?php echo e(old('kode_daerah')); ?>">
                        </div>
                        
                        
                        <div class="mb-3">
                            <label for="nama_instansi" class="form-label">Nama Instansi</label>
                            <input type="text" class="form-control" id="nama_instansi" name="nama_instansi" placeholder="Nama Instansi" value="<?php echo e(old('nama_instansi')); ?>">
                        </div>
                        
                        
                        <div class="mb-3">
                            <label for="satuan_kerja" class="form-label">Satuan Kerja</label>
                            <input type="text" class="form-control" id="satuan_kerja" name="satuan_kerja" placeholder="Contoh: Diskominfo" value="<?php echo e(old('satuan_kerja')); ?>">
                        </div>

                        
                        <div class="mb-3">
                            <label for="tujuan" class="form-label">Tujuan</label>
                            <input type="text" class="form-control" id="tujuan" name="tujuan" placeholder="Tujuan kunjungan" value="<?php echo e(old('tujuan')); ?>">
                        </div>

                        
                        <div class="mb-3">
                            <label for="tgl_kunjungan" class="form-label">Tanggal Kunjungan</label>
                            <input type="date" class="form-control" id="tgl_kunjungan" name="tgl_kunjungan" value="<?php echo e(old('tgl_kunjungan')); ?>" placeholder="dd / mm / yyyy">
                        </div>

                        
                        <div class="mb-3">
                            <label for="file_kunjungan" class="form-label">File Kunjungan (PDF/JPG/PNG)</label>
                            <input class="form-control <?php $__errorArgs = ['file_kunjungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="file_kunjungan" name="file_kunjungan" accept=".pdf,.jpg,.jpeg,.png">
                        </div>
                        
                        
                        <div class="mb-3">
                            <label for="file_spt" class="form-label">File SPT (PDF)</label>
                            <input class="form-control <?php $__errorArgs = ['file_spt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="file_spt" name="file_spt" accept=".pdf">
                        </div>

                    </div>
                    
                    
                    <div class="col-md-6 ps-md-4">
                        <h5 class="mt-2 mb-4 input-group-label">Data Perwakilan</h5>
                        
                        
                        <div class="mb-3">
                            <label for="nama_perwakilan" class="form-label">Nama Perwakilan</label>
                            <input type="text" class="form-control" id="nama_perwakilan" name="nama_perwakilan" placeholder="Nama lengkap" value="<?php echo e(old('nama_perwakilan')); ?>">
                        </div>
                        
                        
                        <div class="mb-3">
                            <label for="jabatan_perwakilan" class="form-label">Jabatan</label>
                            <input type="text" class="form-control" id="jabatan_perwakilan" name="jabatan_perwakilan" placeholder="Jabatan" value="<?php echo e(old('jabatan_perwakilan')); ?>">
                        </div>
                        
                        
                        <div class="mb-3">
                            <label for="email_perwakilan" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email_perwakilan" name="email_perwakilan" placeholder="email@contoh.go.id" value="<?php echo e(old('email_perwakilan')); ?>">
                        </div>
                        
                        
                        <div class="mb-3">
                            <label for="wa_perwakilan" class="form-label">No. WhatsApp</label>
                            <input type="text" class="form-control" id="wa_perwakilan" name="wa_perwakilan" placeholder="08xx..." value="<?php echo e(old('wa_perwakilan')); ?>">
                        </div>

                    </div>
                </div>
                
                
                <hr class="mt-4 mb-3">
                <div class="d-flex justify-content-end gap-2">
                    
                    <a href="<?php echo e(route('kunjungan.index')); ?>" class="btn btn-outline-secondary">Batal</a>
                    <button type="submit" class="btn btn-success btn-success-custom">
                        <i class="bi bi-save-fill me-2"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\bual_kawan\resources\views/kunjungan/tambah_kunjungan.blade.php ENDPATH**/ ?>