<header class="header-full">
<div class="header-inner">
    <div class="logo">
    <img src="https://bualkawan.siakkab.go.id/logo-bualkawan.png" alt="logo">
    <div class="brand">E-Singgah</div>
    </div>

    <div class="header-spacer"></div>

    <div class="header-center-wrap">
        <?php if (isset($component)) { $__componentOriginald72862a8fd8940dc4e34acf463941d36 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald72862a8fd8940dc4e34acf463941d36 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.desktop-nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('desktop-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald72862a8fd8940dc4e34acf463941d36)): ?>
<?php $attributes = $__attributesOriginald72862a8fd8940dc4e34acf463941d36; ?>
<?php unset($__attributesOriginald72862a8fd8940dc4e34acf463941d36); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald72862a8fd8940dc4e34acf463941d36)): ?>
<?php $component = $__componentOriginald72862a8fd8940dc4e34acf463941d36; ?>
<?php unset($__componentOriginald72862a8fd8940dc4e34acf463941d36); ?>
<?php endif; ?>
    </div>

    <div class="header-spacer" style="width:20px"></div>
</div>
</header><?php /**PATH C:\laragon\www\bual_kawan\resources\views/components/header.blade.php ENDPATH**/ ?>