<?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['title' => 'Berita']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Berita']); ?>
  <li class="breadcrumb-item" aria-hidden="false">
    <i class="fas fa-newspaper"></i>
    <strong style="margin-left:6px">Berita</strong>
    </li>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Berita']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Berita']); ?>
  <div class="search-bar">
        <input type="text" id="searchInput" placeholder="Cari berita berdasarkan judul atau isi..." onkeyup="window.filterNews()" />
        <button onclick="window.filterNews()"><i class="fas fa-search"></i> Cari</button>
    </div>

    <div id="news-container" class="news-grid">
        </div>

    <div id="no-results" class="no-results" style="display:none;">
        <i class="fas fa-exclamation-circle"></i> Tidak ada berita yang ditemukan.
    </div>

    <div id="pagination-controls" class="pagination">
        </div>

    <section class="content-section" aria-labelledby="beritaTitle">
    <h2 id="beritaTitle" style="margin:8px 0 12px">Berita Terbaru</h2>
    <div class="berita-list">
      <article class="berita-item">
        <h3><a href="<?php echo e(route('berita-detail')); ?>">Judul Berita Pertama</a></h3>
        <p class="berita-meta">Dipublikasikan pada 1 Januari 2024</p>
        <p>Ringkasan singkat dari berita pertama. Ini adalah deskripsi singkat yang memberikan gambaran tentang isi berita.</p>
      </article>
      <article class="berita-item">
        <h3><a href="<?php echo e(route('berita-detail')); ?>">Judul Berita Kedua</a></h3>
        <p class="berita-meta">Dipublikasikan pada 15 Januari 2024</p>
        <p>Ringkasan singkat dari berita kedua. Ini adalah deskripsi singkat yang memberikan gambaran tentang isi berita.</p>
      </article>
      <article class="berita-item">
        <h3><a href="<?php echo e(route('berita-detail')); ?>">Judul Berita Ketiga</a></h3>
        <p class="berita-meta">Dipublikasikan pada 28 Januari 2024</p>
        <p>Ringkasan singkat dari berita ketiga. Ini adalah deskripsi singkat yang memberikan gambaran tentang isi berita.</p>
      </article>
    </div>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\bual_kawan\resources\views/berita/berita.blade.php ENDPATH**/ ?>