<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Pengajuan Tamu']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Pengajuan Tamu']); ?>
<div class="container py-4">
  <h3 class="fw-bold mb-4">Form Pengajuan Tamu</h3>

  <form action="<?php echo e(route('pengunjung.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
      <label>Nama Instansi</label>
      <input type="text" name="nama_instansi" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Satuan Kerja</label>
      <input type="text" name="satuan_kerja" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Tujuan</label>
      <input type="text" name="tujuan" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Tanggal Kunjungan</label>
      <input type="date" name="tgl_kunjungan" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Nama Perwakilan</label>
      <input type="text" name="nama_perwakilan" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Email Perwakilan</label>
      <input type="email" name="email_perwakilan" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>WA Perwakilan</label>
      <input type="text" name="wa_perwakilan" class="form-control" required>
    </div>

    <button type="submit" class="btn btn-primary">Kirim Pengajuan</button>
  </form>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\bual_kawan\resources\views/pengunjung/create.blade.php ENDPATH**/ ?>