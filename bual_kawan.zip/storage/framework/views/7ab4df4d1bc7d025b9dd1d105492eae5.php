<?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['title' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Detail Kunjungan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Detail Kunjungan']); ?>
    <div class="container py-5">
        <div class="detail-card shadow-lg mx-auto p-5" style="max-width: 1000px;">
            
            <h2 class="mb-4 fw-bold">Detail Laporan Kunjungan</h2>
            
            
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            
            <?php if(!isset($pengunjung)): ?>
                <div class="alert alert-warning text-center">Data pengunjung tidak ditemukan.</div>
            <?php else: ?>
            
            <div class="row">
                
                
                
                
                <div class="col-md-6 border-end pe-md-5">
                    <h4 class="section-title">Data <?php echo e(ucfirst($pengunjung->tipe_pengunjung)); ?></h4>
                    
                    <div class="mb-3">
                        <div class="detail-label">Asal Daerah:</div>
                        <div class="detail-value"><?php echo e($pengunjung->kode_daerah ?? '-'); ?></div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="detail-label">Nama Instansi:</div>
                        <div class="detail-value"><?php echo e($pengunjung->nama_instansi ?? '-'); ?></div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="detail-label">Satuan Kerja:</div>
                        <div class="detail-value"><?php echo e($pengunjung->satuan_kerja ?? '-'); ?></div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="detail-label">Tujuan Kunjungan:</div>
                        <div class="detail-value"><?php echo e($pengunjung->tujuan ?? '-'); ?></div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="detail-label">Tanggal Kunjangan:</div>
                        <div class="detail-value"><?php echo e(\Carbon\Carbon::parse($pengunjung->tgl_kunjungan)->format('Y-m-d')); ?></div>
                    </div>

                    <div class="mb-3">
                        <div class="detail-label">File Kunjungan:</div>
                        <div class="detail-value">
                            <?php if($pengunjung->file_kunjungan): ?>
                                <a href="<?php echo e(Storage::url($pengunjung->file_kunjungan)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-file-earmark-arrow-down-fill me-1"></i> Lihat File Kunjungan
                                </a>
                            <?php else: ?>
                                <span class="text-muted">Tidak ada file kunjungan yang terlampir.</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    
                    <div class="mb-3">
                        <div class="detail-label fw-semibold">File Surat Perintah Tugas (SPT):</div>
                        <div class="detail-value mt-2">
                            <?php if($pengunjung->dokumen && $pengunjung->dokumen->file_spt): ?>
                                
                                <a href="<?php echo e(Storage::url($pengunjung->dokumen->file_spt)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-file-earmark-pdf-fill me-1"></i> Lihat SPT
                                </a>
                                
                                
                                <button type="button" class="btn btn-sm btn-outline-warning ms-2" 
                                        data-bs-toggle="modal" data-bs-target="#uploadSptModal">
                                    <i class="bi bi-arrow-repeat me-1"></i> Ganti File
                                </button>

                            <?php else: ?>
                                
                                <span class="text-muted me-3">Tidak ada file SPT yang terlampir.</span>
                                
                                
                                <button type="button" class="btn btn-sm btn-genz" 
                                        data-bs-toggle="modal" data-bs-target="#uploadSptModal">
                                    <i class="bi bi-cloud-arrow-up me-1"></i> Lampirkan File SPT
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                
                
                <div class="col-md-6 ps-md-5">
                    <h4 class="section-title">Data Perwakilan</h4>
                    
                    <div class="mb-3">
                        <div class="detail-label">Nama:</div>
                        
                        <div class="detail-value"><?php echo e($perwakilanPeserta->nama ?? '-'); ?></div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="detail-label">Jabatan:</div>
                        
                        <div class="detail-value"><?php echo e($perwakilanPeserta->jabatan ?? '-'); ?></div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="detail-label">Email:</div>
                        
                        <div class="detail-value"><?php echo e($perwakilanPeserta->email ?? '-'); ?></div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="detail-label">WhatsApp:</div>
                        
                        <div class="detail-value"><?php echo e($perwakilanPeserta->wa ?? '-'); ?></div>
                    </div>
                </div>
            </div>
            
            <hr class="mt-4 mb-4">

            
            <div class="row">
                <div class="col-md-4 text-center border-end">
                    <h4 class="section-title mt-0">QR Code (untuk absen)</h4>

                    
                    <?php if($pengunjung->status === 'selesai'): ?>
                        <div class="alert alert-secondary mt-3">
                            <i class="bi bi-check-circle-fill"></i> Kunjungan telah **Selesai**.
                        </div>
                    <?php else: ?>
                        
                        <div class="qr-code-area mb-3">
                            <?php if($pengunjung->qrCode && $pengunjung->qrCode->qr_scan_path): ?>
                                
                                
                                <img src="<?php echo e(Storage::url($pengunjung->qrCode->qr_scan_path)); ?>" 
                                    alt="QR Code Kunjungan"
                                    width="200"
                                    height="200"
                                    class="border rounded shadow-sm">
                                
                                
                                <p class="mt-2 text-muted small">
                                    **QR Berisi Link Input Peserta Rombongan**
                                    <br>Berlaku hingga: 
                                    <span class="fw-semibold"><?php echo e(\Carbon\Carbon::parse($pengunjung->qrCode->berlaku_sampai)->format('d M Y H:i')); ?></span>
                                </p>
                            <?php else: ?>
                                <div class="alert alert-warning py-2">
                                    QR Code belum dibuat. silahkan hubungi admin untuk pembuatan QR Code.
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="col-md-8">
                    <h4 class="section-title mt-0">Rombongan</h4>
                    <p class="fw-bold">Daftar peserta:</p>
                    
                    <div class="table-responsive">
                        <table class="table table-sm table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>NIP</th>
                                    <th>Jabatan</th>
                                    
                                </tr>
                            </thead>

                            <tbody>
                                
                                <?php $__empty_1 = true; $__currentLoopData = $anggotaRombongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($peserta->nama); ?></td>
                                        <td>
                                            <?php if(in_array($pengunjung->status, ['disetujui', 'kunjungan', 'selesai'])): ?>
                                                ***************
                                            <?php else: ?>
                                                <?php echo e($peserta->nip ?? '-'); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($peserta->jabatan ?? '-'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center text-muted">
                                            Tidak ada peserta rombongan yang terdaftar.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="text-end mt-4">
                <a href="<?php echo e(route('kunjungan.index')); ?>" class="btn btn-secondary">Kembali ke Daftar</a>
            </div>
            
            <?php endif; ?>
        </div>
    </div>
    
    
    <?php if(isset($pengunjung)): ?>
    <div class="modal fade" id="uploadSptModal" tabindex="-1" aria-labelledby="uploadSptModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold" id="uploadSptModalLabel">
                        <i class="bi bi-file-earmark-arrow-up text-genz"></i> Unggah Dokumen SPT
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <form action="<?php echo e(route('kunjungan.upload.spt', $pengunjung->uid)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
                    <div class="modal-body">
                        <div class="alert alert-info small" role="alert">
                            File wajib berformat **PDF** dan ukuran maksimum **2MB**.
                        </div>
                        
                        <label for="file_spt_upload" class="form-label fw-semibold">Pilih File Surat Perintah Tugas (SPT)</label>
                        <input class="form-control" type="file" id="file_spt_upload" name="file_spt" accept="application/pdf" required>

                        <?php $__errorArgs = ['file_spt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-genz">
                            <i class="bi bi-upload me-1"></i> Unggah & Simpan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\bual_kawan\resources\views/kunjungan/detail.blade.php ENDPATH**/ ?>