<?php if (isset($component)) { $__componentOriginal2e6fb18f75884c4fed4e10444e669251 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2e6fb18f75884c4fed4e10444e669251 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-admin','data' => ['title' => 'Manajemen Slider']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Manajemen Slider']); ?>

  <h2 class="mb-4 fw-bold text-color">Manajemen Slider / Banner 🎡</h2>

  <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show mb-3" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <div class="card p-4">

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
      <h5 class="fw-bold text-color mb-2 mb-md-0">Daftar Slider Aktif</h5>
      <div class="d-flex gap-2">
        <a href="<?php echo e(route('admin.slider.create')); ?>" class="btn btn-sm btn-primary">
            <i class="bi bi-plus-lg"></i> Tambah Slider
        </a>
        <button onclick="window.location.reload()" class="btn btn-sm btn-outline-secondary">
          <i class="bi bi-arrow-clockwise"></i> Refresh
        </button>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table table-hover align-middle table-borderless">
        <thead class="table-primary">
          <tr>
            <th>No</th>
            <th style="width: 200px;">Preview Banner</th>
            <th>Judul Slider</th>
            <th>Keterangan</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($sliders->firstItem() + $no); ?></td>
            <td>
                <img src="<?php echo e(asset('storage/' . $item->image)); ?>" 
                     alt="Slider Img" 
                     class="img-fluid rounded shadow-sm" 
                     style="height: 60px; width: 150px; object-fit: cover;">
            </td>
            <td>
              <span class="fw-bold text-color"><?php echo e($item->title); ?></span>
              <br>
              <small class="text-muted"><?php echo e($item->created_at->format('d M Y')); ?></small>
            </td>
            <td><?php echo e($item->description ?? '-'); ?></td>
            <td class="text-end">
                <form onsubmit="return confirm('Yakin hapus slider ini?');" 
                      action="<?php echo e(route('admin.slider.destroy', $item->id)); ?>" 
                      method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm btn-danger" title="Hapus">
                        <i class="bi bi-trash"></i>
                    </button>
                </form>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="5" class="text-center text-muted py-4">
                <i class="bi bi-tv fs-3 d-block mb-2"></i>
                Belum ada slider/banner yang dipasang.
            </td>
          </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <div class="mt-3 d-flex justify-content-end">
      <?php echo e($sliders->links()); ?>

    </div>

  </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2e6fb18f75884c4fed4e10444e669251)): ?>
<?php $attributes = $__attributesOriginal2e6fb18f75884c4fed4e10444e669251; ?>
<?php unset($__attributesOriginal2e6fb18f75884c4fed4e10444e669251); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e6fb18f75884c4fed4e10444e669251)): ?>
<?php $component = $__componentOriginal2e6fb18f75884c4fed4e10444e669251; ?>
<?php unset($__componentOriginal2e6fb18f75884c4fed4e10444e669251); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\bual_kawan\resources\views/admin/slider/index.blade.php ENDPATH**/ ?>