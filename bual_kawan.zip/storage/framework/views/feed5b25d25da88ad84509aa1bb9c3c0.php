<?php if (isset($component)) { $__componentOriginal2e6fb18f75884c4fed4e10444e669251 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2e6fb18f75884c4fed4e10444e669251 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-admin','data' => ['title' => 'Verifikasi Pengunjung']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Verifikasi Pengunjung']); ?>
  <div class="tab-pane fade show active" id="pengajuan" role="tabpanel">
    <h2 class="mb-4 fw-bold text-color">Daftar Pengajuan Kunjungan 📋</h2>
      <?php if(session('success')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
              <?php echo session('success'); ?>

              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
      <?php endif; ?>

      <?php if(session('error')): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <?php echo session('error'); ?>

              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
      <?php endif; ?>

        <!-- Filter -->
        <form method="GET" action="<?php echo e(route('admin.pengajuan')); ?>" class="mb-4">
            <div class="card p-3 filter-box shadow-sm">
                <h5 class="fw-bold mb-3"><i class="bi bi-funnel-fill me-2"></i> Filter dan Pencarian</h5>
                
                <div class="row g-3">
                    
                    
                    <div class="col-md-3">
                        <label for="statusFilter" class="form-label fw-semibold">Status Kunjungan</label>
                        <select name="status" id="statusFilter" class="form-select form-select-sm">
                            <option value="all">-- Semua Status --</option>
                            <option value="pengajuan" <?php echo e(request('status') == 'pengajuan' ? 'selected' : ''); ?>>Menunggu (Pengajuan)</option>
                            <option value="disetujui" <?php echo e(request('status') == 'disetujui' ? 'selected' : ''); ?>>Disetujui</option>
                            <option value="kunjungan" <?php echo e(request('status') == 'kunjungan' ? 'selected' : ''); ?>>Kunjungan Aktif</option>
                            <option value="selesai" <?php echo e(request('status') == 'selesai' ? 'selected' : ''); ?>>Selesai</option>
                            <option value="ditolak" <?php echo e(request('status') == 'ditolak' ? 'selected' : ''); ?>>Ditolak</option>
                        </select>
                    </div>

                    
                    <div class="col-md-3">
                        <label for="tipeFilter" class="form-label fw-semibold">Tipe Pengunjung</label>
                        <select name="tipe" id="tipeFilter" class="form-select form-select-sm">
                            <option value="all">-- Semua Tipe --</option>
                            
                            <option value="instansi pemerintah" <?php echo e(request('tipe') == 'instansi pemerintah' ? 'selected' : ''); ?>>Instansi Pemerintah</option>
                            <option value="masyarakat umum" <?php echo e(request('tipe') == 'masyarakat umum' ? 'selected' : ''); ?>>Umum/Perorangan</option>
                        </select>
                    </div>
                    
                    
                    <div class="col-md-4">
                        <label for="searchQuery" class="form-label fw-semibold">Pencarian</label>
                        <div class="input-group input-group-sm">
                            <input type="text" name="search" id="searchQuery" class="form-control" placeholder="Cari Instansi / Perwakilan..." value="<?php echo e(request('search')); ?>">
                            <button class="btn btn-primary" type="submit">
                                <i class="bi bi-search"></i> Cari
                            </button>
                        </div>
                    </div>

                    
                    <div class="col-md-2 d-flex align-items-end">
                        <a href="<?php echo e(route('admin.pengajuan')); ?>" class="btn btn-sm btn-outline-secondary w-100">
                            <i class="bi bi-arrow-clockwise"></i> Reset Filter
                        </a>
                    </div>
                </div>
            </div>
        </form>

        <!-- Tabel -->
        <div class="card p-4">
          <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
            <h5 class="fw-bold text-color mb-2 mb-md-0">Data Pengajuan Terbaru</h5>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('admin.pengajuan.export')); ?>" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-download"></i> Export Excel
                </a>
                <button class="btn btn-sm btn-genz"><i class="bi bi-plus-circle"></i> Tambah Manual</button>
            </div>
          </div>

          <div class="table-responsive">
        <table class="table table-hover align-middle table-borderless pengajuan-table" id="dataPengajuan">
          <thead>
            <tr>
              <th>#</th>
              <th>Pengaju / Instansi</th>
              <th class="d-none d-md-table-cell">Tujuan Kunjungan</th>
              <th>Tanggal & Waktu</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $pengunjungs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr data-status="<?php echo e(ucfirst($p->status)); ?>">
              <td><?php echo e($no+1); ?></td>
              <td>
          <span class="fw-semibold text-color"><?php echo e($p->nama_perwakilan); ?></span>
          <div class="text-muted-genz"><?php echo e($p->nama_instansi); ?></div>
              </td>
              <td class="d-none d-md-table-cell"><?php echo e($p->tujuan); ?></td>
              <td><?php echo e(\Carbon\Carbon::parse($p->tgl_kunjungan)->format('d M Y')); ?></td>
              <td>
          <span class="badge 
            <?php if($p->status=='pengajuan'): ?> bg-secondary 
            <?php elseif($p->status=='disetujui'): ?> bg-success 
            <?php elseif($p->status=='kunjungan'): ?> bg-info 
            <?php elseif($p->status=='selesai'): ?> bg-primary
            <?php else: ?> bg-dark <?php endif; ?>">
            <?php echo e(ucfirst($p->status)); ?>

          </span>
              </td>

              <!-- Tombol Aksi (tidak memakai data-bs-toggle / data-bs-target) -->
              <td class="text-nowrap">
          <!-- Tombol Detail (boleh tetap) -->
          <a href="<?php echo e(route('admin.pengajuan.show', $p->uid)); ?>" class="btn btn-sm btn-genz" title="Lihat Detail"><i class="bi bi-eye"></i></a>

            <?php if($p->status == 'kunjungan'): ?>
            <!-- Jika sudah disetujui: tampilkan tombol Selesai -->
            <button type="button"
              class="btn btn-sm btn-primary ms-1 btn-action"
              data-status="selesai"
              data-id="<?php echo e($p->uid); ?>"
              data-icon="bi-check2-square text-primary"
              data-message="Apakah kamu yakin ingin menandai pengajuan ini SELESAI?">
              <i class="bi bi-check2-square"></i> Selesai
            </button>
            <?php elseif($p->status == 'disetujui' || $p->status == 'selesai'): ?>
            <button class="btn btn-sm btn-secondary ms-1" title="Tidak Ada Aksi Lagi" disabled><i class="bi bi-lock"></i></button>
            <?php else: ?>
            <!-- Tombol Setujui: hanya data-* attributes, buka modal lewat JS -->
            <button type="button"
              class="btn btn-sm btn-success ms-1 btn-action"
              data-status="disetujui"
              data-id="<?php echo e($p->uid); ?>"
              data-icon="bi-check-circle text-success"
              data-message="Apakah kamu yakin ingin MENYETUJUI pengajuan ini?">
              <i class="bi bi-check2-circle"></i> Terima
            </button>

            <!-- Tombol Tolak
            <button type="button"
              class="btn btn-sm btn-danger ms-1 btn-action"
              data-status="ditolak"
              data-id="<?php echo e($p->uid); ?>"
              data-icon="bi-x-circle text-danger"
              data-message="Apakah kamu yakin ingin MENOLAK pengajuan ini?">
              <i class="bi bi-x-circle"></i> Tolak
            </button -->
            <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="6" class="text-center text-muted">Tidak ada data pengajuan kunjungan.</td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <div class="mt-3 d-flex justify-content-center">
        <?php echo e($pengunjungs->links()); ?>

      </div>
    </div>
  </div>

  <!-- ======================================================
       Single Modal (LETakkan hanya SEKALI di luar loop)
       ====================================================== -->
  <div class="modal fade" id="actionModal" tabindex="-1" aria-labelledby="actionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title fw-bold" id="actionModalLabel">Konfirmasi Aksi</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body text-center">
          <div class="action-icon mb-3">
            <i id="modalIcon" class="bi fs-1"></i>
          </div>
          <p id="modalMessage" class="fs-5 fw-semibold"></p>
          <p class="text-muted">ID Pengajuan: <span id="modalIdDisplay" class="fw-bold"></span></p>
        </div>

        <div class="modal-footer justify-content-center">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>

          <!-- Form yang akan dikirim ketika user klik Lanjutkan -->
          <form id="modalActionForm" method="POST" class="d-inline">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="status" id="modalStatusValue">
            <button type="submit" class="btn" id="modalConfirmButton">Lanjutkan</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- ======================================================
       Script: isi modal + buka modal hanya lewat JS (NO data-bs attributes)
       ====================================================== -->
  <script>
  document.addEventListener('DOMContentLoaded', function() {
    const modalEl = document.getElementById('actionModal');
    if (!modalEl) return;

    const bsModal = new bootstrap.Modal(modalEl, {});
    const modalIcon = document.getElementById('modalIcon');
    const modalMessage = document.getElementById('modalMessage');
    const modalIdDisplay = document.getElementById('modalIdDisplay');
    const modalConfirmButton = document.getElementById('modalConfirmButton');
    const modalStatusValue = document.getElementById('modalStatusValue');
    const modalForm = document.getElementById('modalActionForm');

    document.querySelectorAll('.btn-action').forEach(btn => {
      btn.addEventListener('click', function() {
        const id = this.dataset.id;
        const status = this.dataset.status;
        const icon = this.dataset.icon;
        const message = this.dataset.message;

        modalIcon.className = `bi fs-1 ${icon}`;
        modalMessage.textContent = message;
        modalIdDisplay.textContent = id;

        modalConfirmButton.className = `btn ${status === 'disetujui' ? 'btn-success' : 'btn-danger'}`;
        modalStatusValue.value = status;

        // gunakan helper url() agar sesuai dengan base URL Laravel (route admin)
        modalForm.action = `<?php echo e(url('pengajuan')); ?>/${id}/status`;

        bsModal.show();
      });
    });

    modalForm.addEventListener('submit', function() {
      modalConfirmButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Memproses...';
    });
  });
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2e6fb18f75884c4fed4e10444e669251)): ?>
<?php $attributes = $__attributesOriginal2e6fb18f75884c4fed4e10444e669251; ?>
<?php unset($__attributesOriginal2e6fb18f75884c4fed4e10444e669251); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e6fb18f75884c4fed4e10444e669251)): ?>
<?php $component = $__componentOriginal2e6fb18f75884c4fed4e10444e669251; ?>
<?php unset($__componentOriginal2e6fb18f75884c4fed4e10444e669251); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\bual_kawan\resources\views/admin/pengajuan.blade.php ENDPATH**/ ?>