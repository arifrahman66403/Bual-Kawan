<?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['title' => 'Statistik']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Statistik']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Statistik Kunjungan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Statistik Kunjungan']); ?>
  <section aria-labelledby="statTitle">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:8px;flex-wrap:wrap">
          <h2 id="statTitle" style="margin:0;font-size:1.05rem">Ringkasan Statistik</h2>
          <div style="color:var(--muted);font-weight:700">Data diperbarui: <span id="lastUpdated">—</span></div>
        </div>

        <div class="stats-grid" id="statsGrid">
          <div class="stat-card c-green" aria-hidden="false">
            <div class="stat-icon"><i class="fas fa-users" style="color:#fff;font-size:26px"></i></div>
            <div class="stat-body">
              <h3 id="stat-total">2.345</h3>
              <p>Total Pengunjung</p>
            </div>
          </div>

          <div class="stat-card c-blue">
            <div class="stat-icon"><i class="fas fa-book-open" style="color:#fff;font-size:26px"></i></div>
            <div class="stat-body">
              <h3 id="stat-today">28</h3>
              <p>Buku Tamu Hari Ini</p>
            </div>
          </div>

          <div class="stat-card c-purple">
            <div class="stat-icon"><i class="fas fa-chart-line" style="color:#fff;font-size:26px"></i></div>
            <div class="stat-body">
              <h3 id="stat-avg">4.2</h3>
              <p>Rata-rata Kunjungan / Hari</p>
            </div>
          </div>

          <div class="stat-card c-orange">
            <div class="stat-icon"><i class="fas fa-globe-asia" style="color:#fff;font-size:26px"></i></div>
            <div class="stat-body">
              <h3 id="stat-outside">512</h3>
              <p>Tamu Luar Daerah</p>
            </div>
          </div>

          <div class="stat-card c-pink">
            <div class="stat-icon"><i class="fas fa-thumbs-up" style="color:#fff;font-size:26px"></i></div>
            <div class="stat-body">
              <h3 id="stat-feedback">89%</h3>
              <p>Feedback Positif</p>
            </div>
          </div>
        </div>
      </section>

      <section aria-labelledby="chartsTitle">
        <h3 id="chartsTitle" style="margin:8px 0 12px">Grafik Kunjungan</h3>
        <div class="charts-grid">
          <div class="chart-card">
            <h4>Pengunjung per Bulan</h4>
            <div class="canvas-wrap"><canvas id="chartMonthly"></canvas></div>
          </div>
          <div class="chart-card">
            <h4>Asal Daerah (Top 5)</h4>
            <div class="canvas-wrap"><canvas id="chartOrigin"></canvas></div>
          </div>
          <div class="chart-card">
            <h4>Rating Feedback</h4>
            <div class="canvas-wrap"><canvas id="chartFeedback"></canvas></div>
          </div>
      </div>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\bual_kawan\resources\views/statistik.blade.php ENDPATH**/ ?>