<footer class="app-footer">
    &copy; 2025 Bual Kawan - All rights reserved. | Made with <i class="bi bi-heart-fill text-danger"></i> by Tim Developer
</footer><?php /**PATH C:\laragon\www\bual_kawan\resources\views/components/footer-admin.blade.php ENDPATH**/ ?>