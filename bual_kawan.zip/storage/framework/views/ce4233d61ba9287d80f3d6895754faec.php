<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Status Kunjungan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Status Kunjungan']); ?>
    
    
    <?php
        // Ambil status atau default ke 'info' jika tidak ada
        $status_type = $status ?? 'info';
        
        // Tentukan styling berdasarkan status
        $icon_class = 'bi-info-circle-fill text-primary';
        $title = 'Informasi Kunjungan';
        $border_class = 'border-primary';

        if ($status_type == 'expired') {
            $icon_class = 'bi-x-octagon-fill text-danger';
            $title = 'Link Kadaluarsa!';
            $border_class = 'border-danger';
        } elseif ($status_type == 'disetujui' || $status_type == 'kunjungan') {
            $icon_class = 'bi-check-circle-fill text-success';
            $title = 'Status Aktif';
            $border_class = 'border-success';
        } elseif ($status_type == 'ditolak' || $status_type == 'selesai') {
            $icon_class = 'bi-slash-circle-fill text-secondary';
            $title = 'Status Non-Aktif';
            $border_class = 'border-secondary';
        }
    ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card p-5 text-center shadow-lg border-bottom-0 border-3 <?php echo e($border_class); ?>">
                    
                    
                    <i class="bi <?php echo e($icon_class); ?>" style="font-size: 4rem;"></i>
                    
                    <h2 class="fw-bold mt-3" style="color: <?php echo e($border_class == 'border-danger' ? '#dc3545' : ($border_class == 'border-success' ? '#198754' : '#0d6efd')); ?>"><?php echo e($title); ?></h2>
                    
                    <hr>
                    
                    
                    <p class="lead mt-3"><?php echo $message; ?></p>
                    
                    <p class="text-muted small mt-4">
                        Data Pengajuan: 
                        <?php if($pengunjung): ?>
                            <?php echo e($pengunjung->nama_instansi); ?> (Perwakilan: <?php echo e($pengunjung->nama_perwakilan); ?>)
                        <?php else: ?>
                            (Data tidak tersedia)
                        <?php endif; ?>
                    </p>

                    <a href="<?php echo e(route('kunjungan.index')); ?>" class="btn btn-outline-secondary mt-4">
                        <i class="bi bi-house"></i> Kembali ke Buku Tamu
                    </a>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\bual_kawan\resources\views/kunjungan/status.blade.php ENDPATH**/ ?>