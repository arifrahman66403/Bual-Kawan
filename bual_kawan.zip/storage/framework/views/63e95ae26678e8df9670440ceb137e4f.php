<?php if (isset($component)) { $__componentOriginal2e6fb18f75884c4fed4e10444e669251 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2e6fb18f75884c4fed4e10444e669251 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-admin','data' => ['title' => 'Galeri Foto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Galeri Foto']); ?>
    <div class="container py-5">
        <div class="card shadow-lg">
            <div class="card-body p-4">
                
                <h2 class="mb-4 fw-bold">Daftar Galeri Foto</h2>
                
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><i class="bi bi-check-circle-fill"></i> <?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <div class="d-flex justify-content-between align-items-center mb-4">
                    <a href="<?php echo e(route('gallery.create')); ?>" class="btn btn-success me-3">
                        <i class="bi bi-plus-circle-fill me-1"></i> Tambah Foto
                    </a>
                    
                    <button onclick="window.location.href='<?php echo e(route('gallery.index')); ?>'" class="btn btn-outline-secondary me-auto" title="Refresh Data">
                        <i class="bi bi-arrow-clockwise"></i>
                    </button>

                    <form method="GET" action="<?php echo e(route('gallery.index')); ?>">
                        <div class="input-group" style="width: 300px;">
                            <input type="text" name="search" class="form-control" placeholder="Cari judul foto..." value="<?php echo e(request('search')); ?>">
                            <button class="btn btn-outline-secondary" type="submit"><i class="bi bi-search"></i></button>
                        </div>
                    </form>
                </div>
                
                <div class="row g-4">
                    <?php $__empty_1 = true; $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-4">
                            <div class="card h-100 border shadow-sm">
                                <div style="height: 200px; overflow: hidden;" class="bg-light d-flex align-items-center justify-content-center">
                                    <img src="<?php echo e(asset('storage/' . $gallery->image)); ?>" class="card-img-top" alt="<?php echo e($gallery->title); ?>" style="object-fit: cover; height: 100%; width: 100%;">
                                </div>
                                
                                <div class="card-body">
                                    <h5 class="card-title fw-bold"><?php echo e($gallery->title); ?></h5>
                                    <p class="card-text text-muted small"><?php echo e(Str::limit($gallery->description, 80) ?? 'Tidak ada deskripsi.'); ?></p>
                                    <p class="card-text"><small class="text-muted"><i class="bi bi-calendar"></i> <?php echo e($gallery->created_at->format('d-m-Y')); ?></small></p>
                                </div>

                                <div class="card-footer bg-white border-top-0 d-flex justify-content-end pb-3">
                                    <form onsubmit="return confirm('Apakah Anda yakin ingin menghapus foto ini?');" action="<?php echo e(route('gallery.destroy', $gallery->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="bi bi-trash"></i> Hapus
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12">
                            <div class="alert alert-secondary text-center py-5">
                                <i class="bi bi-images fs-1 d-block mb-3"></i>
                                Belum ada foto di galeri saat ini.
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($galleries->links()); ?>

                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2e6fb18f75884c4fed4e10444e669251)): ?>
<?php $attributes = $__attributesOriginal2e6fb18f75884c4fed4e10444e669251; ?>
<?php unset($__attributesOriginal2e6fb18f75884c4fed4e10444e669251); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e6fb18f75884c4fed4e10444e669251)): ?>
<?php $component = $__componentOriginal2e6fb18f75884c4fed4e10444e669251; ?>
<?php unset($__componentOriginal2e6fb18f75884c4fed4e10444e669251); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\bual_kawan\resources\views/gallery/index.blade.php ENDPATH**/ ?>