<?php if (isset($component)) { $__componentOriginal2e6fb18f75884c4fed4e10444e669251 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2e6fb18f75884c4fed4e10444e669251 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-admin','data' => ['title' => 'Detail Pengajuan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Detail Pengajuan']); ?>
    <div class="container-fluid p-4">
        
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>
        
        <a href="<?php echo e(route('admin.pengajuan')); ?>" class="btn btn-outline-secondary mb-3">&larr; Kembali</a>

        <div class="row g-3">
            <div class="col-lg-8">
                
                
                <div class="card mb-3">
                    <div class="card-body">
                        <h4 class="mb-3">Informasi Pengajuan</h4>
                        <table class="table table-borderless">
                            <tr><th>UID</th><td><?php echo e($pengunjung->uid); ?></td></tr>
                            <tr><th>Tipe Pengunjung</th><td><?php echo e($pengunjung->tipe_pengunjung); ?></td></tr>
                            <tr><th>Kode Daerah</th><td><?php echo e($pengunjung->kode_daerah); ?></td></tr>
                            <tr><th>Nama Instansi</th><td><?php echo e($pengunjung->nama_instansi); ?></td></tr>
                            <tr><th>Satuan Kerja</th><td><?php echo e($pengunjung->satuan_kerja); ?></td></tr>
                            <tr><th>Tujuan</th><td><?php echo e($pengunjung->tujuan); ?></td></tr>
                            <tr><th>Tanggal Kunjungan</th><td><?php echo e(\Carbon\Carbon::parse($pengunjung->tgl_kunjungan)->format('Y-m-d')); ?></td></tr>
                            <tr><th>Status</th><td><span class="badge bg-info text-dark"><?php echo e($pengunjung->status); ?></span></td></tr>
                        </table>
                    </div>
                </div>

                
                <div class="card mb-3">
                    <div class="card-body">
                        <h5>Perwakilan Utama</h5>
                        <p><strong><?php echo e($pengunjung->nama_perwakilan ?? '-'); ?></strong> — <?php echo e($pengunjung->jabatan_perwakilan ?? '-'); ?><br>
                        Email: <?php echo e($pengunjung->email_perwakilan ?? '-'); ?> — WA: <?php echo e($pengunjung->wa_perwakilan ?? '-'); ?><br>
                    </div>
                </div>

                
                <div class="card mb-3">
                    <div class="card-body">
                        <h5>Dokumen / File</h5>
                        
                        <h6 class="mt-2">File Kunjungan</h6>
                        <?php if($pengunjung->file_kunjungan): ?>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">
                                    <a href="<?php echo e(Storage::url($pengunjung->file_kunjungan)); ?>" target="_blank" class="fw-semibold">
                                        <i class="bi bi-file-earmark-arrow-down me-1"></i> Download File Kunjungan
                                    </a>
                                </li>
                            </ul>
                        <?php else: ?>
                            <div class="text-muted">
                                <i class="bi bi-x-circle-fill text-danger me-1"></i> Belum ada file kunjungan yang terlampir.
                            </div>
                        <?php endif; ?>
                        
                        
                        <h6 class="mt-4">Surat Perintah Tugas (SPT)</h6>
                        <?php if($pengunjung->dokumen && $pengunjung->dokumen->file_spt): ?>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">
                                    
                                    <a href="<?php echo e(Storage::url($pengunjung->dokumen->file_spt)); ?>" target="_blank" class="fw-semibold">
                                        <i class="bi bi-file-earmark-pdf me-1"></i> Download Surat Perintah Tugas (SPT)
                                    </a>
                                    <small class="text-muted d-block">
                                        Diupload: <?php echo e($pengunjung->dokumen->created_at ? $pengunjung->dokumen->created_at->format('Y-m-d H:i') : '-'); ?>

                                    </small>
                                </li>
                            </ul>
                        <?php else: ?>
                            
                            <div class="text-muted">
                                <i class="bi bi-x-circle-fill text-danger me-1"></i> Belum ada dokumen SPT yang terlampir.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="card mb-3">
                    <div class="card-body">
                        <h5>Anggota Rombongan (Tambahan)</h5>
                        
                        <?php if($pengunjung->peserta && is_iterable($pengunjung->peserta) && count($pengunjung->peserta) > 0): ?>
                            <table class="table table-sm table-striped">
                                <thead>
                                    <tr><th>No</th>
                                        <th>Nama</th>
                                        <th>Jabatan</th>
                                        <th>Nip</th>
                                        <th>TTD</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pengunjung->peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($peserta && is_object($peserta)): ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($peserta->nama ?? '-'); ?></td>
                                                <td><?php echo e($peserta->jabatan ?? '-'); ?></td>
                                                <td><?php echo e($peserta->nip ?? '-'); ?></td>
                                                
                                                <td class="text-center">
                                                    <?php if($peserta->file_ttd): ?>
                                                        <div class="ttd-container p-1 border rounded bg-white d-inline-block">
                                                            <img src="<?php echo e(Storage::url($peserta->file_ttd)); ?>" 
                                                                alt="TTD <?php echo e($peserta->nama); ?>" 
                                                                class="img-fluid" 
                                                                style="height: 60px; max-width: 100px; object-fit: contain;">
                                                        </div>
                                                    <?php else: ?>
                                                        <span class="text-muted small font-italic">-</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="text-muted">Belum ada peserta rombongan tambahan yang terdaftar.</div>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="card mb-3">
                    <div class="card-body">
                        <h5>Riwayat Tracking</h5>
                        <?php if($pengunjung->tracking && is_iterable($pengunjung->tracking) && count($pengunjung->tracking) > 0): ?>
                            <ul class="list-group">
                                <?php $__currentLoopData = $pengunjung->tracking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($track && is_object($track)): ?>
                                        <li class="list-group-item">
                                            <strong><?php echo e($track->status ?? '-'); ?></strong>
                                            <div class="small text-muted">oleh: <?php echo e($track->createdBy && $track->createdBy->name ? $track->createdBy->name : 'System'); ?> — <?php echo e($track->created_at ? $track->created_at->format('Y-m-d H:i') : '-'); ?></div>
                                            <?php if(!empty($track->catatan)): ?>
                                                <div class="mt-1"><?php echo e($track->catatan); ?></div>
                                            <?php endif; ?>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <div class="text-muted">Belum ada riwayat tracking.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-4">
                
                
                <div class="card mb-3">
                    <div class="card-body text-center">
                        <h5>QR Code</h5>
                        <?php if($pengunjung->qrCode && !empty($pengunjung->qrCode->qr_scan_path)): ?>
                            <img src="<?php echo e(Storage::url($pengunjung->qrCode->qr_scan_path)); ?>" alt="QR Code" class="img-fluid mb-2" style="max-width:220px;">
                            <div class="d-grid gap-2">
                                <a href="<?php echo e(Storage::url($pengunjung->qrCode->qr_scan_path)); ?>" target="_blank" class="btn btn-outline-primary btn-sm">Buka Gambar QR</a>
                            </div>
                            <div class="small text-muted mt-2">
                                Berlaku mulai: <?php echo e($pengunjung->qrCode->berlaku_mulai ? \Carbon\Carbon::parse($pengunjung->qrCode->berlaku_mulai)->format('Y-m-d H:i') : '-'); ?><br>
                                Berlaku sampai: <?php echo e($pengunjung->qrCode->berlaku_sampai ? \Carbon\Carbon::parse($pengunjung->qrCode->berlaku_sampai)->format('Y-m-d H:i') : '-'); ?>

                            </div>
                        <?php else: ?>
                            <div class="text-muted">Belum ada QR Code</div>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="card mb-3">
                    <div class="card-body">
                        <h5>Aksi Admin</h5>

                        <form action="<?php echo e(route('admin.pengajuan.status', $pengunjung->uid)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <label class="form-label">Ubah Status</label>
                                <select name="status" class="form-select" required>
                                    <option value="pengajuan" <?php echo e($pengunjung->status === 'pengajuan' ? 'selected' : ''); ?>>Pengajuan</option>
                                    <option value="disetujui" <?php echo e($pengunjung->status === 'disetujui' ? 'selected' : ''); ?>>Disetujui</option>
                                    <option value="kunjungan" <?php echo e($pengunjung->status === 'kunjungan' ? 'selected' : ''); ?>>Kunjungan</option>
                                    <option value="selesai" <?php echo e($pengunjung->status === 'selesai' ? 'selected' : ''); ?>>Selesai</option>
                                </select>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2e6fb18f75884c4fed4e10444e669251)): ?>
<?php $attributes = $__attributesOriginal2e6fb18f75884c4fed4e10444e669251; ?>
<?php unset($__attributesOriginal2e6fb18f75884c4fed4e10444e669251); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2e6fb18f75884c4fed4e10444e669251)): ?>
<?php $component = $__componentOriginal2e6fb18f75884c4fed4e10444e669251; ?>
<?php unset($__componentOriginal2e6fb18f75884c4fed4e10444e669251); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\bual_kawan\resources\views/admin/detail-pengajuan.blade.php ENDPATH**/ ?>