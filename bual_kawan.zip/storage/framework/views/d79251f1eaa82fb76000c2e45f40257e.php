<div class="row">
    <div class="col-12 mb-4 desktop-nav-icons">
        <div class="d-flex flex-wrap justify-content-center">
            <?php if (isset($component)) { $__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-link-admin','data' => ['href' => ''.e(route('admin.dashboard')).'','class' => 'nav-link-icon','icon' => 'bi-speedometer2','label' => 'Dashboard','id' => 'nav-dashboard','active' => request()->routeIs('admin.dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-link-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.dashboard')).'','class' => 'nav-link-icon','icon' => 'bi-speedometer2','label' => 'Dashboard','id' => 'nav-dashboard','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.dashboard'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460)): ?>
<?php $attributes = $__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460; ?>
<?php unset($__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460)): ?>
<?php $component = $__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460; ?>
<?php unset($__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-link-admin','data' => ['href' => ''.e(route('admin.pengajuan')).'','class' => 'nav-link-icon','icon' => 'bi-send-plus','label' => 'Pengajuan','id' => 'nav-pengajuan','active' => request()->routeIs('admin.pengajuan')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-link-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.pengajuan')).'','class' => 'nav-link-icon','icon' => 'bi-send-plus','label' => 'Pengajuan','id' => 'nav-pengajuan','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.pengajuan'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460)): ?>
<?php $attributes = $__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460; ?>
<?php unset($__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460)): ?>
<?php $component = $__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460; ?>
<?php unset($__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-link-admin','data' => ['href' => ''.e(route('admin.riwayat')).'','class' => 'nav-link-icon','icon' => 'bi-clock-history','label' => 'Riwayat Tamu','id' => 'nav-riwayat','active' => request()->routeIs('admin.riwayat')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-link-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.riwayat')).'','class' => 'nav-link-icon','icon' => 'bi-clock-history','label' => 'Riwayat Tamu','id' => 'nav-riwayat','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.riwayat'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460)): ?>
<?php $attributes = $__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460; ?>
<?php unset($__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460)): ?>
<?php $component = $__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460; ?>
<?php unset($__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-link-admin','data' => ['href' => ''.e(route('admin.gallery.index')).'','class' => 'nav-link-icon','icon' => 'bi-images','label' => 'Gallery','id' => 'nav-gallery','active' => request()->routeIs('admin.gallery.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-link-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.gallery.index')).'','class' => 'nav-link-icon','icon' => 'bi-images','label' => 'Gallery','id' => 'nav-gallery','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.gallery.index'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460)): ?>
<?php $attributes = $__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460; ?>
<?php unset($__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460)): ?>
<?php $component = $__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460; ?>
<?php unset($__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-link-admin','data' => ['href' => ''.e(route('admin.slider.index')).'','class' => 'nav-link-icon','icon' => 'bi-film','label' => 'Slider Foto','id' => 'nav-slider','active' => request()->routeIs('admin.slider.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-link-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.slider.index')).'','class' => 'nav-link-icon','icon' => 'bi-film','label' => 'Slider Foto','id' => 'nav-slider','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.slider.index'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460)): ?>
<?php $attributes = $__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460; ?>
<?php unset($__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460)): ?>
<?php $component = $__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460; ?>
<?php unset($__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-link-admin','data' => ['href' => ''.e(route('admin.users.index')).'','class' => 'nav-link-icon','icon' => 'bi-people','label' => 'Admin','id' => 'nav-admin','active' => request()->routeIs('admin.users.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-link-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.users.index')).'','class' => 'nav-link-icon','icon' => 'bi-people','label' => 'Admin','id' => 'nav-admin','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.users.index'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460)): ?>
<?php $attributes = $__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460; ?>
<?php unset($__attributesOriginal06948c43ddc3f7ed9cbfe6b16ff06460); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460)): ?>
<?php $component = $__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460; ?>
<?php unset($__componentOriginal06948c43ddc3f7ed9cbfe6b16ff06460); ?>
<?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\bual_kawan\resources\views/components/desktop-nav-admin.blade.php ENDPATH**/ ?>