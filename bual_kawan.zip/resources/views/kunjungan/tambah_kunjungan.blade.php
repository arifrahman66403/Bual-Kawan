<x-layout title="Form Tambah Kunjungan Baru">
    <div class="container py-5">
        <div class="form-card shadow-lg mx-auto p-4" style="max-width: 1000px;">
            
            <h3 class="mb-4 fw-bold">Form Daftar Kunjungan</h3>
            
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            
            @if (session('error'))
                <div class="alert alert-danger">{{ session('error') }}</div>
            @endif

            {{-- Form action menuju route yang sudah kita buat --}}
            <form action="{{ route('kunjungan.store') }}" method="POST" enctype="multipart/form-data">
                @csrf

                <div class="row">
                    
                    {{-- ==================== KOLOM KIRI: DATA INSTANSI & DOKUMEN ==================== --}}
                    <div class="col-md-6 border-end pe-md-4">
                        <h5 class="mt-2 mb-4 input-group-label">Data Instansi</h5>

                        {{-- Tipe Pengunjung (kis_pengunjung.tipe_pengunjung) --}}
                        <div class="mb-3">
                            <label class="form-label d-block">Tipe Pengunjung</label>
                                <input type="radio" name="tipe_pengunjung" value="instansi pemerintah" id="tipe_instansi" {{ old('tipe_pengunjung') == 'instansi pemerintah' ? 'checked' : '' }}>
                                <label for="tipe_instansi" class="me-3">Instansi Pemerintah</label>
                                <input type="radio" name="tipe_pengunjung" value="masyarakat umum" id="tipe_masyarakat" {{ old('tipe_pengunjung') == 'masyarakat umum' ? 'checked' : '' }}>
                                <label for="tipe_masyarakat">Masyarakat Umum</label>
                        </div>
                        
                        {{-- Asal Daerah (kis_pengunjung.kode_daerah) --}}
                        <div class="mb-3">
                            <label for="kode_daerah" class="form-label">Asal Daerah</label>
                            <input type="text" class="form-control" id="kode_daerah" name="kode_daerah" placeholder="Contoh: Riau" value="{{ old('kode_daerah') }}">
                        </div>
                        
                        {{-- Nama Instansi (kis_pengunjung.nama_instansi) --}}
                        <div class="mb-3">
                            <label for="nama_instansi" class="form-label">Nama Instansi</label>
                            <input type="text" class="form-control" id="nama_instansi" name="nama_instansi" placeholder="Nama Instansi" value="{{ old('nama_instansi') }}">
                        </div>
                        
                        {{-- Satuan Kerja (kis_pengunjung.satuan_kerja) --}}
                        <div class="mb-3">
                            <label for="satuan_kerja" class="form-label">Satuan Kerja</label>
                            <input type="text" class="form-control" id="satuan_kerja" name="satuan_kerja" placeholder="Contoh: Diskominfo" value="{{ old('satuan_kerja') }}">
                        </div>

                        {{-- Tujuan (kis_pengunjung.tujuan) --}}
                        <div class="mb-3">
                            <label for="tujuan" class="form-label">Tujuan</label>
                            <input type="text" class="form-control" id="tujuan" name="tujuan" placeholder="Tujuan kunjungan" value="{{ old('tujuan') }}">
                        </div>

                        {{-- Tanggal Kunjungan (kis_pengunjung.tgl_kunjungan) --}}
                        <div class="mb-3">
                            <label for="tgl_kunjungan" class="form-label">Tanggal Kunjungan</label>
                            <input type="date" class="form-control" id="tgl_kunjungan" name="tgl_kunjungan" value="{{ old('tgl_kunjungan') }}" placeholder="dd / mm / yyyy">
                        </div>

                        {{-- File Kunjungan (kis_pengunjung.file_kunjungan) --}}
                        <div class="mb-3">
                            <label for="file_kunjungan" class="form-label">File Kunjungan (PDF/JPG/PNG)</label>
                            <input class="form-control @error('file_kunjungan') is-invalid @enderror" type="file" id="file_kunjungan" name="file_kunjungan" accept=".pdf,.jpg,.jpeg,.png">
                        </div>
                        
                        {{-- File SPT (kis_dokumen.file_spt) --}}
                        <div class="mb-3">
                            <label for="file_spt" class="form-label">File SPT (PDF)</label>
                            <input class="form-control @error('file_spt') is-invalid @enderror" type="file" id="file_spt" name="file_spt" accept=".pdf">
                        </div>

                    </div>
                    
                    {{-- ==================== KOLOM KANAN: DATA PERWAKILAN & KONTAK ==================== --}}
                    <div class="col-md-6 ps-md-4">
                        <h5 class="mt-2 mb-4 input-group-label">Data Perwakilan</h5>
                        
                        {{-- Nama Perwakilan (kis_pengunjung.nama_perwakilan) --}}
                        <div class="mb-3">
                            <label for="nama_perwakilan" class="form-label">Nama Perwakilan</label>
                            <input type="text" class="form-control" id="nama_perwakilan" name="nama_perwakilan" placeholder="Nama lengkap" value="{{ old('nama_perwakilan') }}">
                        </div>
                        
                        {{-- Jabatan (kis_peserta_kunjungan.jabatan) - Perwakilan dijadikan Peserta 0 --}}
                        <div class="mb-3">
                            <label for="jabatan_perwakilan" class="form-label">Jabatan</label>
                            <input type="text" class="form-control" id="jabatan_perwakilan" name="jabatan_perwakilan" placeholder="Jabatan" value="{{ old('jabatan_perwakilan') }}">
                        </div>
                        
                        {{-- Email (kis_pengunjung.email_perwakilan) --}}
                        <div class="mb-3">
                            <label for="email_perwakilan" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email_perwakilan" name="email_perwakilan" placeholder="email@contoh.go.id" value="{{ old('email_perwakilan') }}">
                        </div>
                        
                        {{-- No. WhatsApp (kis_pengunjung.wa_perwakilan) --}}
                        <div class="mb-3">
                            <label for="wa_perwakilan" class="form-label">No. WhatsApp</label>
                            <input type="text" class="form-control" id="wa_perwakilan" name="wa_perwakilan" placeholder="08xx..." value="{{ old('wa_perwakilan') }}">
                        </div>

                    </div>
                </div>
                
                {{-- Tombol Aksi --}}
                <hr class="mt-4 mb-3">
                <div class="d-flex justify-content-end gap-2">
                    {{-- Menggunakan route kunjungan.index yang merupakan Daftar Kunjungan Aktif --}}
                    <a href="{{ route('kunjungan.index') }}" class="btn btn-outline-secondary">Batal</a>
                    <button type="submit" class="btn btn-success btn-success-custom">
                        <i class="bi bi-save-fill me-2"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</x-layout>
