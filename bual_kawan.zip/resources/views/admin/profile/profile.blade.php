<x-layout-admin title="Profil Saya">
    {{-- Breadcrumb Optional --}}
    {{-- <x-breadcrumb title="Profil Pengguna" /> --}}

    <div class="container py-4 py-md-5">
        <div class="row g-4">

            {{-- KOLOM KIRI: KARTU PROFIL --}}
            <div class="col-md-4">
                <div class="card shadow-sm border-0 text-center h-100">
                    <div class="card-body p-4">
                        {{-- Foto Profil (Menggunakan UI Avatar berdasarkan nama jika tidak ada foto) --}}
                        <div class="mb-3 position-relative d-inline-block">
                            @if(Auth::user()->avatar)
                                <img src="{{ asset('storage/' . Auth::user()->avatar) }}" 
                                     class="rounded-circle img-thumbnail shadow-sm" 
                                     style="width: 120px; height: 120px; object-fit: cover;" 
                                     alt="Foto Profil">
                            @else
                                <img src="https://ui-avatars.com/api/?name={{ urlencode(Auth::user()->name) }}&background=0d6efd&color=fff&size=128" 
                                     class="rounded-circle img-thumbnail shadow-sm" 
                                     style="width: 120px; height: 120px;" 
                                     alt="Avatar">
                            @endif
                            
                            {{-- Badge Role --}}
                            <span class="position-absolute bottom-0 start-100 translate-middle badge rounded-pill bg-warning text-dark border border-light">
                                {{ ucfirst(Auth::user()->role) }}
                            </span>
                        </div>

                        <h5 class="fw-bold mb-1">{{ Auth::user()->name }}</h5>
                        <p class="text-muted mb-3">{{ Auth::user()->email }}</p>

                        <hr>

                        <div class="text-start">
                            <small class="text-muted fw-bold text-uppercase">Info Tambahan</small>
                            <ul class="list-unstyled mt-2 mb-0 small text-secondary">
                                <li class="mb-2">
                                    <i class="bi bi-calendar-check me-2 text-primary"></i> 
                                    Bergabung: {{ Auth::user()->created_at->format('d M Y') }}
                                </li>
                                <li>
                                    <i class="bi bi-shield-lock me-2 text-primary"></i> 
                                    Status: <span class="badge bg-success bg-opacity-10 text-success">Aktif</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            {{-- KOLOM KANAN: FORM EDIT & PASSWORD --}}
            <div class="col-md-8">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white border-bottom-0 pt-4 px-4">
                        {{-- TAB NAVIGASI --}}
                        <ul class="nav nav-tabs card-header-tabs" id="profileTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active fw-bold" id="edit-tab" data-bs-toggle="tab" data-bs-target="#edit" type="button" role="tab" aria-selected="true">
                                    <i class="bi bi-pencil-square me-1"></i> Edit Profil
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link fw-bold" id="password-tab" data-bs-toggle="tab" data-bs-target="#password" type="button" role="tab" aria-selected="false">
                                    <i class="bi bi-key me-1"></i> Ganti Password
                                </button>
                            </li>
                        </ul>
                    </div>

                    <div class="card-body p-4">
                        
                        {{-- Flash Message Global --}}
                        @if (session('success'))
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="bi bi-check-circle-fill me-1"></i> {{ session('success') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        @endif

                        @if ($errors->any())
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <ul class="mb-0 ps-3">
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        @endif

                        <div class="tab-content" id="profileTabContent">
                            
                            {{-- TAB 1: EDIT PROFIL --}}
                            <div class="tab-pane fade show active" id="edit" role="tabpanel" aria-labelledby="edit-tab">
                                <form action="{{ route('admin.profile.update') }}" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    @method('PUT')

                                    <div class="mb-3">
                                        <label for="nama" class="form-label text-muted small fw-bold">Nama Lengkap</label>
                                        <input type="text" class="form-control @error('nama') is-invalid @enderror" id="nama" name="nama" value="{{ old('nama', Auth::user()->nama) }}">
                                        @error('nama')<div class="invalid-feedback">{{ $message }}</div>@enderror
                                    </div>

                                    <div class="mb-3">
                                        <label for="email" class="form-label text-muted small fw-bold">Alamat Email</label>
                                        <input type="email" class="form-control @error('email') is-invalid @enderror" id="email" name="email" value="{{ old('email', Auth::user()->email) }}">
                                        @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
                                    </div>
                                    
                                    {{-- Optional: Upload Foto --}}
                                    <div class="mb-4">
                                        <label for="avatar" class="form-label text-muted small fw-bold">Ganti Foto Profil</label>
                                        <input type="file" class="form-control @error('avatar') is-invalid @enderror" id="avatar" name="avatar">
                                        <div class="form-text text-muted">Format: JPG, PNG, max 2MB.</div>
                                    </div>

                                    <div class="d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="bi bi-save me-1"></i> Simpan Perubahan
                                        </button>
                                    </div>
                                </form>
                            </div>

                            {{-- TAB 2: GANTI PASSWORD --}}
                            <div class="tab-pane fade" id="password" role="tabpanel" aria-labelledby="password-tab">
                                <form action="{{ route('admin.profile.password') }}" method="POST">
                                    @csrf
                                    @method('PUT')

                                    <div class="mb-3">
                                        <label for="current_password" class="form-label text-muted small fw-bold">Password Saat Ini</label>
                                        <div class="input-group">
                                            <input type="password" class="form-control" id="current_password" name="current_password">
                                            <span class="input-group-text bg-light"><i class="bi bi-lock"></i></span>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="new_password" class="form-label text-muted small fw-bold">Password Baru</label>
                                            <input type="password" class="form-control" id="new_password" name="new_password">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="new_password_confirmation" class="form-label text-muted small fw-bold">Konfirmasi Password Baru</label>
                                            <input type="password" class="form-control" id="new_password_confirmation" name="new_password_confirmation">
                                        </div>
                                    </div>

                                    <div class="alert alert-info py-2 small">
                                        <i class="bi bi-info-circle me-1"></i> Pastikan password minimal 8 karakter.
                                    </div>

                                    <div class="d-flex justify-content-end mt-4">
                                        <button type="submit" class="btn btn-danger">
                                            <i class="bi bi-shield-lock me-1"></i> Perbarui Password
                                        </button>
                                    </div>
                                </form>
                            </div>

                        </div> {{-- End Tab Content --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-layout-admin>