<section class="breadcrumb" aria-label="Breadcrumb">
    <div class="inner">
        <h1>{{ $title }}</h1>
        <div class="crumbs" aria-hidden="false">
        <i class="fas fa-home"></i>
        <span><a href="/" style="color:inherit;text-decoration:underline;font-weight:800;margin-left:6px">Beranda</a></span>
        <span style="opacity:0.85;margin:0 8px"></span>
        <i class="fas fa-file-alt"></i>
        <strong style="margin-left:6px">{{ $title }}</strong>
        </div>
    </div>
</section>