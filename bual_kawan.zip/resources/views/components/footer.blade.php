<footer>
    <p>© 2025 OPD Kabupaten Siak — Jl. Contoh No.1, Siak — Email: info@siak.go.id</p>
    <p>Template Bual Kawan | Powered by Diskominfo Kab. Siak</p>
</footer>