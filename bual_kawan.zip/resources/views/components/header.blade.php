<header class="header-full">
<div class="header-inner">
    <div class="logo">
    <img src="https://bualkawan.siakkab.go.id/logo-bualkawan.png" alt="logo">
    <div class="brand">E-Singgah</div>
    </div>

    <div class="header-spacer"></div>

    <div class="header-center-wrap">
        <x-desktop-nav/>
    </div>

    <div class="header-spacer" style="width:20px"></div>
</div>
</header>