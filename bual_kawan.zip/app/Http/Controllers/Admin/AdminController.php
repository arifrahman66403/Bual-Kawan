<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\KisPengunjung; 
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash; // Tambahan penting untuk password
use Illuminate\Support\Facades\Storage; // Tambahan penting untuk upload foto

class AdminController extends Controller
{
    // =========================================================================
    // 1. DASHBOARD & STATISTIK
    // =========================================================================
    public function index()
    {
        $tanggal_hari_ini = date('Y-m-d');
        $bulan_tahun_ini = date('Y-m');
        $tahun_ini = date('Y');
        
        $total_tamu_hari_ini = KisPengunjung::whereDate('tgl_kunjungan', $tanggal_hari_ini)
                                            ->whereIn('status', ['disetujui', 'kunjungan', 'selesai'])
                                            ->count();
        
        $total_tamu_bulan_ini = KisPengunjung::whereRaw("DATE_FORMAT(tgl_kunjungan, '%Y-%m') = ?", [$bulan_tahun_ini])
                                             ->whereIn('status', ['disetujui', 'kunjungan', 'selesai'])
                                             ->count();
        
        $total_tamu_tahun_ini = KisPengunjung::whereYear('tgl_kunjungan', $tahun_ini)
                                             ->whereIn('status', ['disetujui', 'kunjungan', 'selesai'])
                                             ->count();
        
        $total_tamu_semua = KisPengunjung::count();
        
        // Data 7 hari terakhir (untuk chart)
        $chart_data = KisPengunjung::selectRaw('DATE(tgl_kunjungan) as tanggal, COUNT(*) as total')
                                   ->where('status', 'disetujui')
                                   ->whereBetween('tgl_kunjungan', [now()->subDays(6), now()])
                                   ->groupBy('tanggal')
                                   ->get();
        
        return view('admin.dashboard', compact(
            'total_tamu_hari_ini', 
            'total_tamu_bulan_ini', 
            'total_tamu_tahun_ini', 
            'total_tamu_semua', 
            'chart_data'
        ));
    }

    // =========================================================================
    // 2. MANAJEMEN PENGUNJUNG
    // =========================================================================
    public function pendingList()
    {
        $pending = KisPengunjung::where('status', 'pengajuan')->paginate(10);
        return view('admin.pengunjung.index', ['pengunjungList' => $pending, 'pageTitle' => 'Daftar Pengajuan']);
    }

    public function approvePengunjung($id)
    {
        $pengunjung = KisPengunjung::findOrFail($id);
        if ($pengunjung->status !== 'pengajuan') {
            return back()->with('error', 'Status kunjungan tidak lagi dalam pengajuan.');
        }

        $pengunjung->status = 'disetujui';
        // Pastikan kolom edited_by ada di tabel database kamu, jika tidak hapus baris ini
        $pengunjung->edited_by = Auth::id(); 
        $pengunjung->save();
        
        return back()->with('success', 'Pengajuan kunjungan berhasil disetujui.');
    }
    
    public function allPengunjung()
    {
        $all = KisPengunjung::latest()->paginate(10);
        return view('admin.pengunjung.index', ['pengunjungList' => $all, 'pageTitle' => 'Data Master Pengunjung']);
    }

    // =========================================================================
    // 3. MANAJEMEN PROFIL (BARU DITAMBAHKAN)
    // =========================================================================

    /**
     * Menampilkan halaman profil
     */
    public function profile()
    {
        // Return view sesuai lokasi file blade yang saya buatkan sebelumnya
        // (resources/views/admin/profile/profile.blade.php)
        return view('admin.profile.profile');
    }

    /**
     * Update data diri (Nama, Email, Foto)
     */
    public function updateProfile(Request $request)
    {
        $user = Auth::user();

        // Validasi input
        $request->validate([
            'name' => 'required|string|max:255',
            // Email harus unik, tapi abaikan untuk user yang sedang login ini
            'email' => 'required|email|unique:users,email,' . $user->id,
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg|max:2048', // Max 2MB
        ]);

        // Update Nama & Email
        $user->name = $request->name;
        $user->email = $request->email;

        // Cek jika ada upload foto baru
        if ($request->hasFile('avatar')) {
            // Hapus foto lama jika bukan default/kosong
            if ($user->avatar && Storage::disk('public')->exists($user->avatar)) {
                Storage::disk('public')->delete($user->avatar);
            }

            // Simpan foto baru ke folder 'avatars' di storage public
            $path = $request->file('avatar')->store('avatars', 'public');
            $user->avatar = $path;
        }

        $user->save();

        return back()->with('success', 'Profil berhasil diperbarui!');
    }

    /**
     * Ganti Password
     */
    public function updatePassword(Request $request)
    {
        $request->validate([
            'current_password' => 'required',
            'new_password' => 'required|min:8|confirmed|different:current_password',
        ], [
            'new_password.confirmed' => 'Konfirmasi password baru tidak cocok.',
            'new_password.different' => 'Password baru tidak boleh sama dengan password lama.',
            'new_password.min' => 'Password minimal 8 karakter.'
        ]);

        $user = Auth::user();

        // Cek apakah password lama benar
        if (!Hash::check($request->current_password, $user->password)) {
            return back()->withErrors(['current_password' => 'Password saat ini salah.']);
        }

        // Update password
        $user->password = Hash::make($request->new_password);
        $user->save();

        return back()->with('success', 'Password berhasil diubah!');
    }
}